<footer class="sticky-footer bg-white col-lg" style="position: absolute; bottom:0;
   width:100%; font-size:medium; font-weight:200;
   height:60px; background-image:url(<?= base_url('assets/img/gray-bg.jpg') ?>)">
    <div class="container">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; SAN Website CodeIgniter 3 <?= date('Y') ?></span>
        </div>
    </div>
</footer>
<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/') ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/') ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/') ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/') ?>js/sb-admin-2.min.js"></script>



</body>

</html>